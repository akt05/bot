boş
